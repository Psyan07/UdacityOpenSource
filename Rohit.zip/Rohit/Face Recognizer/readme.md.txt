This model is created to recognize people with their document ids to verify them when they are absent.
This recognizes the person to know their Background details if stored in database.

Main use case of this recognizer is that it can detect the person's image even if their is not muct 
luminance or the person is wearing hat or other things.  